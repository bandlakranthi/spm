<?php
//include config
require_once('../includes/config.php');


//check if already logged in
if( $user->is_logged_in() ){ header('Location: index.php'); } 
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin Login</title>
  <!-- <link rel="stylesheet" href="../style/normalize.css"> -->
  <link rel="stylesheet" href="../style/main.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
    	header {
    		background-color: #59d5d8;
    		height: 150px;
    		padding: 4px;
    	}

    	header h1{
    		text-transform: uppercase;
    		text-align: center;
    		color: #fff;
    		line-height:50px;
    	}

    	header h2 {
    		font-variant: small-caps;
    		text-align: center;
    		color:#fff;
    	}

    	.main_menu {
    		padding: 5px 0 5px 0;
    		text-align: center;
    		line-height: 32px;
    		background-color: #818181;
    	}

    	ul.main_menu {
    		margin-top: 15px;
    	}

    	.main_menu li {
    		display: inline;
    		padding: 0 10px 0 10px;
    		font-size: 20px;
    	}

    	.main_menu a {
    		text-decoration: none;
    		color: #fff;
    		padding: 8px;
    		font-variant: small-caps;
    	}

    	.main_menu a:hover {
    		color: #EF1F2F;
    	}
    </style>
</head>
<body>
    <div id="wrapper">
        <header>
            <h1>Government Schemes</h1>
            <h2>check ur eligibity by applying to them easily.</h2>
        </header>
        <nav>
            <ul class="main_menu">
                <li><a href="../index.php">Home</a></li>
                <li><a href="../about.php">About</a></li>
                <li><a href="#">User Login</a></li>
                <li><a href="#">User Registration</a></li>
                <li><a href="">Admin</a></li>
            </ul>
        </nav>
    
    </div>
	

<div id="login">

	<?php

	//process login form if submitted
	if(isset($_POST['submit'])){

		$username = trim($_POST['username']);
		$password = trim($_POST['password']);
		
		if($user->login($username,$password)){ 

			//logged in return to index page
			header('Location: index.php');
			exit;
		

		} else {
			$message = '<p class="error">Wrong username or password</p>';
		}

	}//end if submit

	if(isset($message)){ echo $message; }
	?>

	<form action="" method="post">
        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" value="">
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="text" name="password" value="">
        </div>
        <div class="input-group">
            <input type="submit" name="submit" value="Login"  />
        </div>
<!-- 	<p><label>Username</label><input type="text" name="username" value=""  /></p>
	<p><label>Password</label><input type="password" name="password" value=""  /></p>
	<p><label></label><input type="submit" name="submit" value="Login"  /></p> -->
	</form>

</div>
</body>
</html>
