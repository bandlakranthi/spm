<?php
//include config
require_once('../includes/config.php');

//if not logged in redirect to login page
if(!$user->is_logged_in()){ header('Location: login.php'); }

//show message from add / edit page
if(isset($_GET['approve'])){ 
	
		$stmt = $db->prepare('UPDATE applied SET status="Approved" WHERE id= :memberID') ;
		$stmt->execute(array(':memberID' => $_GET['approve']));

		header('Location: applications.php?action=Approved');
		exit;
} 
if(isset($_GET['deny'])){ 
	
		$stmt = $db->prepare('UPDATE applied SET status="Denied" WHERE id= :memberID') ;
		$stmt->execute(array(':memberID' => $_GET['deny']));

		header('Location: applications.php?action=Denied');
		exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin - Users</title>
  <link rel="stylesheet" href="../style/normalize.css">
  <link rel="stylesheet" href="../style/main.css">
  <script language="JavaScript" type="text/javascript">
  function deluser(id, title)
  {
	  if (confirm("Are you sure you want to Approve '" + title + "'"))
	  {
	  	window.location.href = 'applications.php?approve=' + id;
	  }
  }
  function deluser2(id, title)
  {
	  if (confirm("Are you sure you want to Deny '" + title + "'"))
	  {
	  	window.location.href = 'applications.php?deny=' + id;
	  }
  }  
  </script>
</head>
<body>

	<div id="wrapper">

	<?php include('menu.php');?>
<!-- <h3>All the applications will appear here for confirmation.</h3>
<h4>Currently NO applications received!</h4> -->

	<?php 
	//show message from add / edit page
	if(isset($_GET['action'])){ 
		echo '<h3>'.$_GET['action'].'.</h3>'; 
	} 
	?>

	<table>
	<tr>
		<th>User</th>
		<th>Name</th>
		<th>Email</th>
		<th>Scheme</th>
		<th>Details</th>
		<th>Status</th>
		<th>Action</th>
	</tr>
	<?php
		try {

			$stmt = $db->query('SELECT * FROM applied');
			while($row = $stmt->fetch()){
				
				echo '<tr>';
				echo '<td>'.$row['user'].'</td>';
				echo '<td>'.$row['name'].'</td>';
				echo '<td>'.$row['email'].'</td>';
				echo '<td>'.$row['scheme'].'</td>';
				echo '<td>'.$row['details'].'</td>';
				echo '<td>'.$row['status'].'</td>';
				?>
				<td>
					<a href="javascript:deluser('<?php echo $row['id'];?>','<?php echo $row['user'];?>')">Approve</a>
					/
					<a href="javascript:deluser2('<?php echo $row['id'];?>','<?php echo $row['user'];?>')">Deny</a>
				</td>
				<?php 
				echo '</tr>';

			}

		} catch(PDOException $e) {
		    echo $e->getMessage();
		}
	?>
	</table>

	<!-- <p><a href='add-user.php'>Add User</a></p> -->

</div>

</body>
</html>
