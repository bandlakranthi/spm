<?php require('../includes/config.php'); ?>
<?php 
$user = $_SESSION['username'];
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Schemes</title>
    <link rel="stylesheet" href="../style/normalize.css">
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
<div id="wrapper">
    <?php include('menu1.php');?>
    <!-- <h3>Status of aplication will appear here!</h3>
    <h4>U haven't applied to any Scheme.</h4> -->
	<table>

	<tr>
		<!-- echo $user ; -->
		<th>User</th>
		<th>Name</th>
		<th>Email</th>
		<th>Scheme</th>
		<th>Details</th>
		<th>Status</th>
		<!-- <th>Action</th> -->
	</tr>
	<?php
	//echo ("SELECT * FROM applied where user = '" . $user . "' " );
	//exit();
		try {

			$stmt = $db->query("SELECT * FROM applied where user = '" . $user . "' " );
			while($row = $stmt->fetch()){
				
				echo '<tr>';
				echo '<td>'.$row['user'].'</td>';
				echo '<td>'.$row['name'].'</td>';
				echo '<td>'.$row['email'].'</td>';
				echo '<td>'.$row['scheme'].'</td>';
				echo '<td>'.$row['details'].'</td>';
				echo '<td>'.$row['status'].'</td>';
				?>
				<!-- <td>
					<a href="javascript:deluser('<?php echo $row['id'];?>','<?php echo $row['user'];?>')">Approve</a>
					/
					<a href="javascript:deluser2('<?php echo $row['id'];?>','<?php echo $row['user'];?>')">Deny</a>
				</td> -->
				<?php 
				echo '</tr>';

			}

		} catch(PDOException $e) {
		    echo $e->getMessage();
		}
	?>
	</table>

</div>
</body>
</html>