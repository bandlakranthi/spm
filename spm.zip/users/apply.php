<?php require('../includes/config.php');
 $name = $email = $scheme = $details = ""; 
$user=$_SESSION['username'];?>
<?php 

 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Schemes</title>
   <!--  <link rel="stylesheet" href="../style/normalize.css"> -->
    <!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../style/main.css">
</head>
<body>
    <div id="wrapper">
    <?php include('menu1.php');?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">

        <div class="form-group">

            <label>Name:</label>

            <input type="text" name="name" value="" class="form-control" required>

        </div>

        <div class="form-group">

            <label>Email:</label>

            <input type="email" name="email" value="" class="form-control" required>

        </div>

        <div class="form-group">

            <label>Scheme Interested:</label>

            <?php 
             $hostname = "localhost";
             $username = "root";
             $password = "";
             $databaseName = "ggg";
             $connect = mysqli_connect($hostname, $username, $password, $databaseName);
            $query = "SELECT postID, postTitle FROM blog_posts";
             $result2 = mysqli_query($connect, $query);
             $options = "";
             while($row2 = mysqli_fetch_array($result2))
             {
                $pid=$row2["postID"];
                $scheme=$row2["postTitle"];
        $options.="<OPTION VALUE=\"$scheme\">".$scheme.'</OPTION>';
             }
             ?>

            <select name="scheme" class="form-control" >
            <?php echo $options; ?>
            </select>

            <!-- <input type="text" name="scheme" value="" class="form-control" required> -->

        </div>

        <div class="form-group">

            <label>Details:</label>

            <textarea class="form-control" name="details" value="" required></textarea>

        </div>

        <div class="form-group">

            <button class="btn btn-success" name="submit" type="submit">Apply</button>

        </div>

    </form>

<?php 

if(isset($_POST['submit']))
{
    $link = mysqli_connect("localhost", "root", "","ggg");
    if($link === false)
    {
        die("ERROR: Could not connect.".mysqli_connect_error());
    }
    //echo $user;
    $name=$_POST['name'];
    $email=$_POST['email'];
    $scheme=$_POST['scheme'];
    $details=$_POST['details'];
    
    // echo "INSERT into applied (id,user,name,email,scheme,details,created_date) VALUES('','" . $user . "','" . $name . "','" . $email . "','" . $scheme . "','" . $details . "','" . date('Y-m-d') . "')";

    $sql = "INSERT into applied (id,user,name,email,scheme,details,created_date) VALUES('','" . $user . "','" . $name . "','" . $email . "','" . $scheme . "','" . $details . "','" . date('Y-m-d') . "')";

    if(mysqli_query($link, $sql))
    {
        echo "Application submitted successfully.";
    }
    else{
    echo "ERROR: Could not able to execute $sql.".mysqlierror($link);
    }

mysqli_close($link);
}
 ?>
  </div>
</body>
</html>