<?php require('includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Blog</title>
    <link rel="stylesheet" href="style/normalize.css">
    <link rel="stylesheet" href="style/main.css">
    <style type="text/css">
    	header {
    		background-color: #59d5d8;
    		height: 150px;
    		padding: 4px;
    	}

    	header h1{
    		text-transform: uppercase;
    		text-align: center;
    		color: #fff;
    		line-height:50px;
    	}

    	header h2 {
    		font-variant: small-caps;
    		text-align: center;
    		color:#fff;
    	}

    	.main_menu {
    		padding: 5px 0 5px 0;
    		text-align: center;
    		line-height: 32px;
    		background-color: #818181;
    	}

    	ul.main_menu {
    		margin-top: 15px;
    	}

    	.main_menu li {
    		display: inline;
    		padding: 0 10px 0 10px;
    		font-size: 20px;
    	}

    	.main_menu a {
    		text-decoration: none;
    		color: #fff;
    		padding: 8px;
    		font-variant: small-caps;
    	}

    	.main_menu a:hover {
    		color: #EF1F2F;
    	}
    </style>
</head>
<body>

	<div id="wrapper">

		<header>
			<h1>Government Schemes</h1>
			<h2>check ur eligibity by applying to them easily.</h2>
		</header>
		<nav>
			<ul class="main_menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="users/login.php">User Login</a></li>
				<li><a href="users/register.php">User Registration</a></li>
				<li><a href="admin/login.php">Admin</a></li>
			</ul>
		</nav>
		
		<hr />

		<?php
			try {

				$stmt = $db->query('SELECT postID, postTitle, postDesc, postDate FROM blog_posts ORDER BY postID DESC');
				while($row = $stmt->fetch()){
					
					echo '<div>';
						echo '<h1><a href="viewpost.php?id='.$row['postID'].'">'.$row['postTitle'].'</a></h1>';
						echo '<p>Posted on '.date('jS M Y H:i:s', strtotime($row['postDate'])).'</p>';
						echo '<p>'.$row['postDesc'].'</p>';				
						echo '<p><a href="viewpost.php?id='.$row['postID'].'">Read More</a></p>';				
					echo '</div>';

				}

			} catch(PDOException $e) {
			    echo $e->getMessage();
			}
		?>

	</div>


</body>
</html>