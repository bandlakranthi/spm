<?php require('includes/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Blog</title>
    <link rel="stylesheet" href="style/normalize.css">
    <link rel="stylesheet" href="style/main.css">
    <style type="text/css">
    	header {
    		background-color: #59d5d8;
    		height: 150px;
    		padding: 4px;
    	}

    	header h1{
    		text-transform: uppercase;
    		text-align: center;
    		color: #fff;
    		line-height:50px;
    	}

    	header h2 {
    		font-variant: small-caps;
    		text-align: center;
    		color:#fff;
    	}

    	.main_menu {
    		padding: 5px 0 5px 0;
    		text-align: center;
    		line-height: 32px;
    		background-color: #818181;
    	}

    	ul.main_menu {
    		margin-top: 15px;
    	}

    	.main_menu li {
    		display: inline;
    		padding: 0 10px 0 10px;
    		font-size: 20px;
    	}

    	.main_menu a {
    		text-decoration: none;
    		color: #fff;
    		padding: 8px;
    		font-variant: small-caps;
    	}

    	.main_menu a:hover {
    		color: #EF1F2F;
    	}
    </style>
</head>
<body>

	<div id="wrapper">

		<header>
			<h1>Government Schemes</h1>
			<h2>check ur eligibity by applying to them easily.</h2>
		</header>
		<nav>
			<ul class="main_menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="#">User Login</a></li>
				<li><a href="#">User Registration</a></li>
				<li><a href="admin/login.php">Admin</a></li>
			</ul>
		</nav>
		
		<hr />

        <h2 style="color:#EF1F2F">Welcome</h2>

        <p>The main motto of this site to make everyone understand the schemes published by government of india and as well as your particular states.</p>
        <p>These blogs in this website are updated with the schemes of government in the regular intervels of time.</p>
        <p>If someone gets interested in a scheme out there, then they can create an account for themselves on this website and can apply to that particular scheme to check their Eligibility.</p>


	</div>


</body>
</html>